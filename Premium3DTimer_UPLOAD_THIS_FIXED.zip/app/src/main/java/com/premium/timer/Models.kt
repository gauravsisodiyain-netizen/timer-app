package com.premium.timer

import org.json.JSONArray
import org.json.JSONObject

enum class TimerStatus { COMPLETED, STOPPED, SKIPPED }

data class Profile(
    val name: String = "",
    val workspace: String = "My Timer",
    val username: String = "@timeruser",
    val memberId: String = "001",
    val memberSince: String = ""
)

data class Session(
    val id: Long,
    val timerName: String,
    val startAt: Long,
    val endAt: Long,
    val plannedSeconds: Long,
    val elapsedSeconds: Long,
    val remainingSeconds: Long,
    val status: TimerStatus,
    val score: Double,
    val completionPercent: Int
)

data class ActiveTimer(
    val timerName: String,
    val plannedSeconds: Long,
    val startAt: Long,
    val endAt: Long,
    val remainingWhenPaused: Long? = null,
    val running: Boolean = true
)

class TimerStore(private val prefs: android.content.SharedPreferences) {
    fun profile(): Profile {
        val p = JSONObject(prefs.getString("profile", "{}") ?: "{}")
        return Profile(p.optString("name"), p.optString("workspace", "My Timer"), p.optString("username", "@timeruser"), p.optString("memberId", "001"), p.optString("memberSince", ""))
    }
    fun saveProfile(profile: Profile) {
        prefs.edit().putString("profile", JSONObject().apply {
            put("name", profile.name); put("workspace", profile.workspace); put("username", profile.username); put("memberId", profile.memberId); put("memberSince", profile.memberSince)
        }.toString()).apply()
    }
    fun sessions(): List<Session> {
        val arr = JSONArray(prefs.getString("sessions", "[]") ?: "[]")
        return buildList {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                add(Session(o.getLong("id"), o.getString("timerName"), o.getLong("startAt"), o.getLong("endAt"), o.getLong("plannedSeconds"), o.getLong("elapsedSeconds"), o.getLong("remainingSeconds"), TimerStatus.valueOf(o.getString("status")), o.getDouble("score"), o.getInt("completionPercent")))
            }
        }.sortedByDescending { it.startAt }
    }
    fun addSession(s: Session) {
        val arr = JSONArray()
        sessions().plus(s).sortedByDescending { it.startAt }.take(500).forEach { x -> arr.put(JSONObject().apply {
            put("id", x.id); put("timerName", x.timerName); put("startAt", x.startAt); put("endAt", x.endAt); put("plannedSeconds", x.plannedSeconds); put("elapsedSeconds", x.elapsedSeconds); put("remainingSeconds", x.remainingSeconds); put("status", x.status.name); put("score", x.score); put("completionPercent", x.completionPercent)
        }) }
        prefs.edit().putString("sessions", arr.toString()).apply()
    }
    fun active(): ActiveTimer? {
        val raw = prefs.getString("active", null) ?: return null
        val o = JSONObject(raw)
        return ActiveTimer(o.getString("timerName"), o.getLong("plannedSeconds"), o.getLong("startAt"), o.getLong("endAt"), if (o.has("remainingWhenPaused") && !o.isNull("remainingWhenPaused")) o.getLong("remainingWhenPaused") else null, o.optBoolean("running", true))
    }
    fun saveActive(a: ActiveTimer) { prefs.edit().putString("active", JSONObject().apply { put("timerName", a.timerName); put("plannedSeconds", a.plannedSeconds); put("startAt", a.startAt); put("endAt", a.endAt); if (a.remainingWhenPaused == null) put("remainingWhenPaused", JSONObject.NULL) else put("remainingWhenPaused", a.remainingWhenPaused); put("running", a.running) }.toString()).apply() }
    fun clearActive() { prefs.edit().remove("active").apply() }
    fun setting(key: String, default: Boolean = true) = prefs.getBoolean(key, default)
    fun settingInt(key: String, default: Int = 0) = prefs.getInt(key, default)
    fun setSettingInt(key: String, value: Int) = prefs.edit().putInt(key, value).apply()
    fun storeOpenCompletion() = prefs.getBoolean("openCompletion", false)
    fun clearOpenCompletion() = prefs.edit().remove("openCompletion").apply()
    fun setSetting(key: String, value: Boolean) = prefs.edit().putBoolean(key, value).apply()
}
