package com.premium.timer

import android.app.*
import android.content.*
import android.os.Build
import androidx.core.app.NotificationCompat

class TimerAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = context.getSharedPreferences("timer_store", Context.MODE_PRIVATE)
        val store = TimerStore(prefs)
        val active = store.active() ?: return
        val now = System.currentTimeMillis()
        if (!active.running || now < active.endAt) return

        // The timer is timestamp based, so the background receiver can safely finish it
        // even if the process was suspended or the screen was off.
        val session = Session(
            id = now,
            timerName = active.timerName,
            startAt = active.startAt,
            endAt = active.endAt,
            plannedSeconds = active.plannedSeconds,
            elapsedSeconds = active.plannedSeconds,
            remainingSeconds = 0L,
            status = TimerStatus.COMPLETED,
            score = 10.0,
            completionPercent = 100
        )
        store.addSession(session)
        store.clearActive()
        prefs.edit().putBoolean("openCompletion", true).apply()

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(
                NotificationChannel("timer", "Timer", NotificationManager.IMPORTANCE_HIGH).apply {
                    description = "Timer completion notifications"
                }
            )
        }
        val pending = PendingIntent.getActivity(
            context, 77,
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("openCompletion", true)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, "timer")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("${active.timerName} completed")
            .setContentText("Your focus session is complete.")
            .setContentIntent(pending)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        manager.notify(77, notification)
    }
}
