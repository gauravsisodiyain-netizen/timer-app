package com.premium.timer

import android.app.*
import android.content.*
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*

private val Bg = Color(0xFF050608); private val Glass = Color(0xFF111319).copy(alpha=.76f); private val Line = Color.White.copy(alpha=.16f); private val Muted = Color.White.copy(alpha=.58f); private val Accent = Color(0xFFFF4B4B)

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); if (android.os.Build.VERSION.SDK_INT >= 33) notificationPermission.launch("android.permission.POST_NOTIFICATIONS")
        setContent { PremiumTimerApp() }
    }
}

class TimerVM(context: Context) {
    val store = TimerStore(context.getSharedPreferences("timer_store", Context.MODE_PRIVATE))
    var profile by mutableStateOf(store.profile()); private set
    var sessions by mutableStateOf(store.sessions()); private set
    var screen by mutableStateOf(when {
        profile.name.isBlank() -> Screen.WELCOME
        store.active() != null -> Screen.ACTIVE
        else -> Screen.HOME
    })
    var selectedMinutes by mutableIntStateOf(25); var selectedHours by mutableIntStateOf(0)
    var active by mutableStateOf(store.active()); private set
    var selectedSessionId by mutableLongStateOf(-1L)
    var remaining by mutableLongStateOf(0); var paused by mutableStateOf(false); private set
    var completionSession by mutableStateOf<Session?>(null); private set
    var query by mutableStateOf(""); var filter by mutableStateOf("All"); var oldestFirst by mutableStateOf(false)
    var reducedMotion by mutableStateOf(store.setting("reducedMotion", false)); var haptics by mutableStateOf(store.setting("haptics", true)); var sound by mutableStateOf(store.setting("sound", true))
    var quality by mutableStateOf(store.setting("highQuality", true))
    fun refresh() {
        val oldActive = active
        sessions = store.sessions(); active = store.active(); profile = store.profile()
        active?.let { remaining = if (it.running) max(0, kotlin.math.ceil((it.endAt-System.currentTimeMillis()) / 1000.0).toLong()) else it.remainingWhenPaused ?: 0; paused = !it.running }
        if (oldActive != null && active == null && screen == Screen.ACTIVE) { completionSession = sessions.firstOrNull(); if (completionSession?.status == TimerStatus.COMPLETED) screen = Screen.COMPLETION }
    }
    fun saveProfile(name:String, workspace:String) { val p=profile.copy(name=name.trim(),workspace=workspace.trim().ifBlank{"My Timer"},username="@"+(name.trim().lowercase().replace(" ","").ifBlank{"timeruser"})); profile=p.copy(memberSince=if(profile.memberSince.isBlank()) SimpleDateFormat("MMM d, yyyy",Locale.US).format(Date()) else profile.memberSince); store.saveProfile(profile); refresh(); screen=Screen.HOME }
    fun startTimer() { val sec=selectedHours*3600L+selectedMinutes*60L; if(sec<=0)return; val now=System.currentTimeMillis(); val a=ActiveTimer(profile.workspace,sec,now,now+sec*1000); store.saveActive(a); active=a; remaining=sec; paused=false; scheduleAlarm(now+sec*1000); screen=Screen.ACTIVE }
    fun pauseResume() { val a=store.active() ?: return; val now=System.currentTimeMillis(); if(a.running){ val r=max(0,kotlin.math.ceil((a.endAt-now)/1000.0).toLong()); cancelAlarm(); store.saveActive(a.copy(remainingWhenPaused=r,running=false)); paused=true; remaining=r } else { val r=a.remainingWhenPaused ?: remaining; val na=a.copy(endAt=now+r*1000,remainingWhenPaused=null,running=true); store.saveActive(na); paused=false; scheduleAlarm(na.endAt) }; refresh() }
    fun stop(status:TimerStatus){ val a=store.active() ?: return; cancelAlarm(); val now=System.currentTimeMillis(); val r=if(a.running) max(0,(a.endAt-now)/1000) else (a.remainingWhenPaused ?: remaining); val elapsed=max(0,a.plannedSeconds-r); val pct=(elapsed*100/a.plannedSeconds).toInt().coerceIn(0,100); val score=score(status,pct); val s=Session(System.currentTimeMillis(),a.timerName,a.startAt,now,a.plannedSeconds,elapsed,r,status,score,pct); store.addSession(s); store.clearActive(); sessions=store.sessions(); active=null; completionSession=s; if(status==TimerStatus.COMPLETED) screen=Screen.COMPLETION else screen=Screen.HOME }
    fun completeIfNeeded(){ val a=store.active()?:return; if(a.running && System.currentTimeMillis()>=a.endAt){ stop(TimerStatus.COMPLETED) } }
    private fun score(status:TimerStatus,pct:Int)=when(status){TimerStatus.COMPLETED->10.0;TimerStatus.STOPPED->(pct/100.0*8.0).coerceIn(0.0,8.0);TimerStatus.SKIPPED->(pct/100.0*5.0).coerceIn(0.0,5.0)}
    private fun scheduleAlarm(at:Long){ val am=ContextCompat.getSystemService(appContext, AlarmManager::class.java) ?: return; val pi=PendingIntent.getBroadcast(appContext,77,Intent(appContext,TimerAlarmReceiver::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE); try{am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi)}catch(_:Throwable){} }
    private fun cancelAlarm(){
        val am = ContextCompat.getSystemService(appContext, AlarmManager::class.java) ?: return
        val pi = PendingIntent.getBroadcast(appContext,77,Intent(appContext,TimerAlarmReceiver::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        am.cancel(pi)
        pi.cancel()
    }
    lateinit var appContext:Context
    init { if (store.storeOpenCompletion()) { completionSession = sessions.firstOrNull { it.status == TimerStatus.COMPLETED }; screen = Screen.COMPLETION; store.clearOpenCompletion() } }
    fun setSetting(key:String,v:Boolean){store.setSetting(key,v); when(key){"reducedMotion"->reducedMotion=v;"haptics"->haptics=v;"sound"->sound=v;"highQuality"->quality=v}}
}

enum class Screen { WELCOME, HOME, SET, ACTIVE, COMPLETION, HISTORY, DETAILS, ANALYTICS, SETTINGS }

@Composable fun PremiumTimerApp(){ val context=LocalContext.current; val vm=remember{TimerVM(context).also{it.appContext=context}}; LaunchedEffect(Unit){ while(true){ vm.refresh(); vm.completeIfNeeded(); delay(250) } }; MaterialTheme(colorScheme=darkColorScheme(background=Bg,surface=Glass,primary=Color.White)){ Surface(Modifier.fillMaxSize(),color=Bg){ AnimatedContent(vm.screen,transitionSpec={fadeIn(tween(350))+scaleIn(initialScale=.98f) togetherWith fadeOut(tween(200))}){s-> when(s){Screen.WELCOME->Welcome(vm);Screen.HOME->Home(vm);Screen.SET->SetTimer(vm);Screen.ACTIVE->ActiveTimer(vm);Screen.COMPLETION->Completion(vm);Screen.HISTORY->History(vm);Screen.DETAILS->Details(vm);Screen.ANALYTICS->Analytics(vm);Screen.SETTINGS->Settings(vm)}} } } }

@Composable
fun AppBackground(modifier: Modifier = Modifier, quality: Boolean = true) {
    val t = rememberInfiniteTransition(label = "bg")
    val shift by t.animateFloat(0f, TAU, infiniteRepeatable(tween(18000, easing = LinearEasing)), label = "shift")
    Canvas(modifier.fillMaxSize()) {
        drawRect(Bg)
        val rows = if (quality) 28 else 16
        val cols = if (quality) 38 else 24
        val amp = size.height * .018f
        for (row in 0 until rows) {
            for (col in 0 until cols) {
                val nx = col.toFloat() / (cols - 1)
                val ny = row.toFloat() / (rows - 1)
                val x = nx * size.width
                val wave = sin(nx * 7.5f + shift + row * .17f) * amp + sin(nx * 3.1f - shift * .65f) * amp * .45f
                val y = ny * size.height + wave
                val depth = .35f + .65f * (sin(row * .55f + shift * .35f) + 1f) / 2f
                val alpha = (.08f + .15f * depth) * if (row < rows * .15f || row > rows * .88f) .75f else 1f
                drawCircle(Color.White.copy(alpha = alpha), radius = if ((row + col) % 11 == 0) 1.35f else .72f, center = Offset(x, y))
            }
        }
    }
}

@Composable fun GlassCard(modifier:Modifier=Modifier,shape:Shape=RoundedCornerShape(26.dp),content:@Composable BoxScope.()->Unit){ Box(modifier.clip(shape).background(Glass).border(1.dp,Line,shape).shadow(18.dp,shape),content=content) }
@Composable fun Header(title:String,back:()->Unit,menu:()->Unit={}){ Row(Modifier.fillMaxWidth().padding(18.dp),verticalAlignment=Alignment.CenterVertically){ CircleButton("‹",back); Spacer(Modifier.width(14.dp)); Text(title,fontSize=28.sp,fontWeight=FontWeight.SemiBold); Spacer(Modifier.weight(1f)); Text("⋮",fontSize=28.sp,modifier=Modifier.clickable{menu()}) } }
@Composable fun CircleButton(text:String,onClick:()->Unit){ Box(Modifier.size(48.dp).clip(CircleShape).background(Color.White.copy(.09f)).border(1.dp,Line,CircleShape).clickable{onClick()},contentAlignment=Alignment.Center){Text(text,fontSize=28.sp,color=Color.White)}}
@Composable fun PillButton(text:String,icon:String,onClick:()->Unit,enabled:Boolean=true){ Row(Modifier.fillMaxWidth().height(64.dp).clip(RoundedCornerShape(32.dp)).background(if(enabled)Color.White else Color.White.copy(.15f)).clickable(enabled){onClick()}.padding(horizontal=9.dp),verticalAlignment=Alignment.CenterVertically){ Spacer(Modifier.weight(1f)); Text(text,fontSize=18.sp,fontWeight=FontWeight.SemiBold,color=if(enabled)Color.Black else Muted); Spacer(Modifier.weight(1f)); Box(Modifier.size(48.dp).clip(CircleShape).background(Color.Black),contentAlignment=Alignment.Center){Text(icon,color=Color.White,fontSize=22.sp)}} }

@Composable fun Welcome(vm:TimerVM){ var name by remember{mutableStateOf("")}; var workspace by remember{mutableStateOf("My Timer")}; Box(Modifier.fillMaxSize()){AppBackground(quality=vm.quality); Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(26.dp),horizontalAlignment=Alignment.CenterHorizontally){ Spacer(Modifier.height(42.dp)); GlassCard(Modifier.fillMaxWidth().widthIn(max=520.dp)){ Column(Modifier.padding(26.dp)){ Box(Modifier.size(58.dp).clip(CircleShape).background(Color.White.copy(.08f)).border(1.dp,Line,CircleShape),contentAlignment=Alignment.Center){Text("◷",fontSize=34.sp)}; Spacer(Modifier.height(20.dp)); Text("Welcome",fontSize=38.sp,fontWeight=FontWeight.Bold); Text("Let's personalize your timer experience",fontSize=17.sp,color=Muted); Spacer(Modifier.height(20.dp)); HorizontalDivider(color=Line); Spacer(Modifier.height(22.dp)); Label("♙","Enter your name","This helps us personalize your experience"); GlassInput(name,"Your name"){name=it}; Spacer(Modifier.height(22.dp)); Label("♧","Create your space","Give your timer a name to make it uniquely yours"); GlassInput(workspace,"My Timer"){workspace=it}; Spacer(Modifier.height(24.dp)); PillButton("Get Started","→",{vm.saveProfile(name,workspace)},name.isNotBlank()); Spacer(Modifier.height(20.dp)); Text("Created by anggidwiiputra",modifier=Modifier.align(Alignment.CenterHorizontally),color=Muted,fontSize=13.sp) } } } } }
@Composable fun Label(icon:String,title:String,desc:String){Row(verticalAlignment=Alignment.Top){Text(icon,fontSize=23.sp);Spacer(Modifier.width(12.dp));Column{Text(title,fontSize=18.sp,fontWeight=FontWeight.SemiBold);Text(desc,fontSize=14.sp,color=Muted)}}}
@Composable fun GlassInput(value:String,placeholder:String,onChange:(String)->Unit){ OutlinedTextField(value,onChange,Modifier.fillMaxWidth(),placeholder= {Text(placeholder,color=Muted)},singleLine=true,shape=RoundedCornerShape(18.dp),colors=OutlinedTextFieldDefaults.colors(focusedTextColor=Color.White,unfocusedTextColor=Color.White,focusedBorderColor=Color.White.copy(.55f),unfocusedBorderColor=Line,focusedContainerColor=Color.White.copy(.03f),unfocusedContainerColor=Color.White.copy(.02f))) }

@Composable fun Home(vm:TimerVM){ val p=vm.profile; Column(Modifier.fillMaxSize()){ Box(Modifier.weight(1f)){AppBackground(quality=vm.quality); Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal=16.dp)){ Row(Modifier.padding(18.dp),verticalAlignment=Alignment.CenterVertically){CircleButton("‹"){ } ; Spacer(Modifier.weight(1f)); Text("⋮",fontSize=28.sp,modifier=Modifier.clickable{vm.screen=Screen.SETTINGS})}; MemberCard(p); Stats(vm.sessions); Recent(vm); ScoreCard(vm); Spacer(Modifier.height(24.dp)) } } BottomNav(vm) } }
@Composable fun MemberCard(p:Profile){ var flip by remember{mutableStateOf(false)}; val rot by animateFloatAsState(if(flip)180f else 0f,tween(650),label="flip"); Box(Modifier.fillMaxWidth().aspectRatio(1.75f).padding(horizontal=4.dp).graphicsLayer{rotationY=rot;cameraDistance=14*density}.clickable{flip=!flip}){ GlassCard(Modifier.fillMaxSize()){ if(rot<90f) Column(Modifier.padding(26.dp)){Text("◷",fontSize=28.sp);Spacer(Modifier.height(12.dp));Text(p.name,fontSize=30.sp,fontWeight=FontWeight.Bold);Text(p.username,color=Muted,fontSize=16.sp);Spacer(Modifier.height(24.dp));Text("MEMBER ID",fontSize=11.sp,color=Muted);Text(p.memberId,fontSize=30.sp);Spacer(Modifier.height(12.dp));Text("Member since ${p.memberSince}",color=Muted)} else Box(Modifier.fillMaxSize().graphicsLayer{rotationY=180f}){ Column(Modifier.fillMaxSize().padding(22.dp)){Text("TIMER MEMBER CARD",color=Muted);Spacer(Modifier.weight(1f));Text("◯  +  △",fontSize=44.sp,color=Color.White.copy(.22f));Spacer(Modifier.weight(1f));Text("MEMBER ${p.memberId}");Text("|||| ||| |||||| | |||",fontSize=22.sp,color=Color.White.copy(.8f))} } } } }
@Composable fun Stats(s:List<Session>){val c=s.count{it.status==TimerStatus.COMPLETED};val st=s.count{it.status==TimerStatus.STOPPED};val sk=s.count{it.status==TimerStatus.SKIPPED};GlassCard(Modifier.fillMaxWidth().padding(top=14.dp)){Row(Modifier.padding(16.dp),horizontalArrangement=Arrangement.SpaceEvenly){Stat("◷","Total Timers",s.size);Stat("✓","Completed",c);Stat("Ⅱ","Stopped",st);Stat("›|","Skipped",sk)}}}
@Composable fun RowScope.Stat(icon:String,title:String,n:Int){Column(Modifier.weight(1f),horizontalAlignment=Alignment.CenterHorizontally){Text(icon,fontSize=20.sp);Text(title,fontSize=11.sp,color=Muted);Text(n.toString(),fontSize=23.sp,fontWeight=FontWeight.Medium)}}
@Composable fun Recent(vm:TimerVM){GlassCard(Modifier.fillMaxWidth().padding(top=14.dp)){Column(Modifier.padding(16.dp)){Row{Text("Recent Timers",fontSize=20.sp,fontWeight=FontWeight.SemiBold);Spacer(Modifier.weight(1f));Text("View All  ›",color=Muted,modifier=Modifier.clickable{vm.screen=Screen.HISTORY})};Spacer(Modifier.height(10.dp));vm.sessions.take(5).forEach{SessionRow(it){ vm.selectedSessionId=it.id; vm.screen=Screen.DETAILS }}}}}
@Composable fun SessionRow(s:Session,onClick:(()->Unit)?=null){Row(Modifier.fillMaxWidth().padding(vertical=10.dp).clickable(enabled=onClick!=null){onClick?.invoke()}, verticalAlignment=Alignment.CenterVertically){CircleButton(if(s.status==TimerStatus.COMPLETED)"◷" else "›|") ;Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(s.timerName,fontSize=15.sp);Text(SimpleDateFormat("MMM d, hh:mm a",Locale.US).format(Date(s.startAt)),fontSize=11.sp,color=Muted)};Column(horizontalAlignment=Alignment.End){Text(s.status.name.lowercase().replaceFirstChar{it.uppercase()},fontSize=12.sp);Text(formatDuration(s.elapsedSeconds),fontSize=14.sp);Text("${"%.1f".format(s.score)}",fontSize=13.sp,color=Muted)}}}
@Composable fun ScoreCard(vm:TimerVM){val avg=if(vm.sessions.isEmpty())0.0 else vm.sessions.map{it.score}.average();val consistency=if(vm.sessions.isEmpty())0 else (vm.sessions.count{it.status==TimerStatus.COMPLETED}*100/vm.sessions.size);GlassCard(Modifier.fillMaxWidth().padding(top=14.dp)){Row(Modifier.padding(22.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Overall Score",fontSize=14.sp);Text("${"%.1f".format(avg)} /10",fontSize=32.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(6.dp));Text("Consistency  $consistency%",color=Muted)}ProgressDonut(consistency/100f)}}}
@Composable fun ProgressDonut(progress:Float){Canvas(Modifier.size(76.dp)){drawArc(Color.White.copy(.12f),-90f,360f,false,style=Stroke(9f));drawArc(Color.White,-90f,360f*progress,false,style=Stroke(9f))}}
@Composable fun BottomNav(vm:TimerVM){Row(Modifier.fillMaxWidth().background(Color.Black.copy(.45f)).padding(10.dp),horizontalArrangement=Arrangement.SpaceAround){Nav("⌂","Home"){vm.screen=Screen.HOME};Nav("◷","Timer"){vm.screen=Screen.SET};Nav("▥","History"){vm.screen=Screen.HISTORY};Nav("◒","Stats"){vm.screen=Screen.ANALYTICS};Nav("⚙","Settings"){vm.screen=Screen.SETTINGS}}}
@Composable fun Nav(i:String,t:String,on:()->Unit){Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.clickable{on()}.padding(5.dp)){Text(i,fontSize=20.sp);Text(t,fontSize=10.sp,color=Muted)}}

@Composable
fun SetTimer(vm:TimerVM){
    Column(Modifier.fillMaxSize().padding(WindowInsets.safeDrawing.only(WindowInsetsSides.Top).asPaddingValues())) {
        Header("Set Time",{vm.screen=Screen.HOME})
        Box(Modifier.fillMaxWidth().height(108.dp)){
            Column(Modifier.padding(start=20.dp)){
                Text("Choose the time duration",fontSize=17.sp,color=Muted)
            }
            GlowingArc(Modifier.align(Alignment.TopEnd).padding(end=24.dp))
        }
        Box(Modifier.weight(1f)){
            AppBackground(quality=vm.quality)
            GlassCard(Modifier.fillMaxWidth().padding(16.dp)){
                Row(Modifier.fillMaxSize().padding(10.dp)){
                    Wheel("Minutes",0..59,vm.selectedMinutes){vm.selectedMinutes=it}
                    Wheel("Hours",0..23,vm.selectedHours){vm.selectedHours=it}
                }
            }
        }
        Column(Modifier.padding(18.dp)){
            PillButton("Start Timer","▶",{vm.startTimer()},vm.selectedMinutes+vm.selectedHours>0)
        }
    }
}

@Composable
fun GlowingArc(modifier: Modifier = Modifier){
    Canvas(modifier.size(120.dp)){
        drawArc(Color.White.copy(.08f),210f,120f,false,style=Stroke(18f))
        drawArc(Color.White.copy(.08f),210f,120f,false,style=Stroke(26f))
        drawArc(Color.White,210f,72f,false,style=Stroke(7f,cap=StrokeCap.Round))
        drawCircle(Color.White.copy(.18f),18f,Offset(size.width*.78f,size.height*.68f))
        drawCircle(Color.White.copy(.75f),6f,Offset(size.width*.78f,size.height*.68f))
    }
}
@Composable
fun Wheel(label:String, range:IntRange, value:Int, onValue:(Int)->Unit){
    val values = (0..2).flatMap { range.toList() }
    val initial = range.count() + value
    val state = rememberLazyListState(initialFirstVisibleItemIndex = initial)
    val rowHeight = 58.dp
    LaunchedEffect(state) {
        snapshotFlow { state.firstVisibleItemIndex }
            .collect { first ->
                val centerIndex = (first + 2).coerceIn(0, values.lastIndex)
                val selected = values[centerIndex]
                if (selected != value) onValue(selected)
            }
    }
    Box(Modifier.weight(1f).fillMaxHeight()) {
        LazyColumn(
            state = state,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(vertical = 150.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            items(values.size) { index ->
                val v = values[index]
                Box(Modifier.height(rowHeight).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text(
                        v.toString().padStart(2,'0'),
                        fontSize = if (v == value) 40.sp else 25.sp,
                        fontWeight = if (v == value) FontWeight.Medium else FontWeight.Normal,
                        color = if (v == value) Color.White else Color.White.copy(.25f)
                    )
                }
            }
        }
        Box(Modifier.align(Alignment.Center).fillMaxWidth().height(58.dp).border(1.dp, Color.White.copy(.16f), RoundedCornerShape(18.dp)))
        Text(label, Modifier.align(Alignment.BottomCenter).padding(bottom = 28.dp), fontSize = 15.sp, color = Color.White)
    }
}

@Composable fun ActiveTimer(vm:TimerVM){ val a=vm.active?:return; val total=a.plannedSeconds; val progress=if(total==0L)0f else 1f-vm.remaining.toFloat()/total; Column(Modifier.fillMaxSize()){Box(Modifier.weight(1f)){AppBackground(quality=vm.quality); Column(Modifier.fillMaxSize(),horizontalAlignment=Alignment.CenterHorizontally){Spacer(Modifier.height(12.dp)); Text(a.timerName,color=Muted); Box(Modifier.weight(1f).fillMaxWidth(),contentAlignment=Alignment.Center){TimerDial(progress,vm.reducedMotion,vm.quality)} GlassCard(Modifier.width(290.dp).height(84.dp)){Row(Modifier.fillMaxSize(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.Center){Text("◷",fontSize=25.sp);Spacer(Modifier.width(12.dp));Text(formatDuration(vm.remaining),fontSize=34.sp,fontWeight=FontWeight.Light)}};Spacer(Modifier.height(24.dp));CircleButton(if(vm.paused)"▶" else "Ⅱ"){vm.pauseResume()};Spacer(Modifier.height(20.dp));Row(Modifier.padding(horizontal=30.dp),horizontalArrangement=Arrangement.spacedBy(16.dp)){SmallAction("STOP"){vm.stop(TimerStatus.STOPPED)};SmallAction("SKIP"){vm.stop(TimerStatus.SKIPPED)}};Spacer(Modifier.height(24.dp))}}}}
@Composable fun RowScope.SmallAction(t:String,on:()->Unit){Box(Modifier.weight(1f).height(48.dp).clip(RoundedCornerShape(24.dp)).border(1.dp,Line,RoundedCornerShape(24.dp)).clickable{on()},contentAlignment=Alignment.Center){Text(t,fontSize=12.sp,color=Muted)}}
@Composable
fun TimerDial(progress:Float,reduced:Boolean,quality:Boolean){
    Box(Modifier.size(370.dp),contentAlignment=Alignment.Center){
        Torus(progress,reduced,quality)
        Text("60",Modifier.align(Alignment.TopCenter).padding(top=2.dp),fontSize=17.sp,color=Color.White.copy(.9f))
        Text("15",Modifier.align(Alignment.CenterEnd).padding(end=2.dp),fontSize=17.sp,color=Color.White.copy(.9f))
        Text("30",Modifier.align(Alignment.BottomCenter).padding(bottom=2.dp),fontSize=17.sp,color=Color.White.copy(.9f))
        Text("45",Modifier.align(Alignment.CenterStart).padding(start=2.dp),fontSize=17.sp,color=Color.White.copy(.9f))
    }
}

@Composable fun Torus(progress:Float,reduced:Boolean,quality:Boolean){val inf=rememberInfiniteTransition(label="torus");val rot by inf.animateFloat(0f,360f,infiniteRepeatable(tween(if(reduced)24000 else 9000,easing=LinearEasing)),label="rot");Canvas(Modifier.size(330.dp)){val cx=size.width/2;val cy=size.height/2;val r=if(size.minDimension<350f)92f else 105f;val minor=38f;val pts=if(quality)320 else 150;for(i in 0 until pts){val u=TAU*i/pts;val v=TAU*((i*37)%pts)/pts;val x=(r+minor*cos(v))*cos(u+rot*PI/180);val z=(r+minor*cos(v))*sin(u+rot*PI/180);val y=minor*sin(v);val perspective=1/(1+z/500);val px=cx+x*perspective;val py=cy+y*perspective;val lit=((cos(v)+sin(u+rot*PI/180)+2)/4);val alpha=.25f+.7f*lit;val radius=1.5f+2.5f*perspective;drawCircle(Color.White.copy(alpha=alpha),radius,Offset(px,py))};drawArc(Color.White.copy(.13f),-90f,360f,false,style=Stroke(3f));drawArc(if(progress>.9f)Accent else Color.White,-90f,360f*progress,false,style=Stroke(7f));for(i in 0 until 60){val a=TAU*i/60-PI/2;val rr=r+82f;val len=if(i%5==0)8f else 4f;drawLine(Color.White.copy(if(i<60*progress) .3f else .12f),Offset(cx+cos(a)*rr,cy+sin(a)*rr),Offset(cx+cos(a)*(rr+len),cy+sin(a)*(rr+len)),strokeWidth=if(i%5==0)2f else 1f)}}

@Composable fun Completion(vm:TimerVM){val s=vm.completionSession;Box(Modifier.fillMaxSize()){AppBackground(quality=vm.quality);Column(Modifier.fillMaxSize().padding(26.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Text("✦",fontSize=60.sp);Text("Completed",fontSize=40.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(12.dp));s?.let{Text(it.timerName,fontSize=20.sp,color=Muted);Text(formatDuration(it.plannedSeconds),fontSize=24.sp);Text("Score ${"%.1f".format(it.score)} · ${it.completionPercent}%",color=Muted)};Spacer(Modifier.height(30.dp));PillButton("Done","✓",{vm.screen=Screen.HOME});Spacer(Modifier.height(12.dp));PillButton("Start Another","▶",{vm.screen=Screen.SET})}}}

@Composable fun History(vm:TimerVM){val list=vm.sessions.filter{(vm.filter=="All"||it.status.name==vm.filter)&&it.timerName.contains(vm.query,true)}.let{if(vm.oldestFirst)it.sortedBy{a->a.startAt}else it};Column(Modifier.fillMaxSize()){Header("History",{vm.screen=Screen.HOME});Column(Modifier.padding(horizontal=16.dp)){GlassInput(vm.query,"Search timers"){vm.query=it};Spacer(Modifier.height(12.dp));Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf("All","COMPLETED","STOPPED","SKIPPED").forEach{f->FilterChip(selected=vm.filter==f,onClick={vm.filter=f},label={Text(f.lowercase().replaceFirstChar{it.uppercase()})})};Text("⇅",Modifier.clickable{vm.oldestFirst=!vm.oldestFirst}.padding(10.dp),fontSize=22.sp)};Spacer(Modifier.height(8.dp));LazyColumn{items(list){SessionRow(it){ vm.selectedSessionId=it.id; vm.screen=Screen.DETAILS }}}}}}
@Composable fun Details(vm:TimerVM){val s=vm.sessions.firstOrNull{it.id==vm.selectedSessionId} ?: vm.sessions.firstOrNull() ?: return;Column(Modifier.fillMaxSize()){Header("Session",{vm.screen=Screen.HISTORY});GlassCard(Modifier.fillMaxWidth().padding(16.dp)){Column(Modifier.padding(24.dp)){Text(s.timerName,fontSize=30.sp,fontWeight=FontWeight.Bold);Text(s.status.name,color=Muted);Spacer(Modifier.height(20.dp));Detail("Date",SimpleDateFormat("MMM d, yyyy",Locale.US).format(Date(s.startAt)));Detail("Start",SimpleDateFormat("hh:mm a",Locale.US).format(Date(s.startAt)));Detail("End",SimpleDateFormat("hh:mm a",Locale.US).format(Date(s.endAt)));Detail("Planned",formatDuration(s.plannedSeconds));Detail("Actual",formatDuration(s.elapsedSeconds));Detail("Completion","${s.completionPercent}%");Detail("Score","${"%.1f".format(s.score)} / 10")}}}}
@Composable fun Detail(k:String,v:String){Row(Modifier.fillMaxWidth().padding(vertical=8.dp)){Text(k,color=Muted,modifier=Modifier.weight(1f));Text(v,fontWeight=FontWeight.Medium)}}

@Composable fun Analytics(vm:TimerVM){val s=vm.sessions;val total=s.size;val focused=s.sumOf{it.elapsedSeconds};val completed=s.count{it.status==TimerStatus.COMPLETED};val stopped=s.count{it.status==TimerStatus.STOPPED};val skipped=s.count{it.status==TimerStatus.SKIPPED};val avg=if(total==0)0 else focused/total;Column(Modifier.fillMaxSize()){Header("Analytics",{vm.screen=Screen.HOME});Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)){MetricGrid(total,focused,completed,stopped,skipped,avg);Spacer(Modifier.height(16.dp));GlassCard(Modifier.fillMaxWidth().height(220.dp)){Column(Modifier.padding(20.dp)){Text("Activity",fontSize=20.sp,fontWeight=FontWeight.SemiBold);Spacer(Modifier.height(20.dp));BarChart(s.take(14).reversed())}};Spacer(Modifier.height(16.dp));GlassCard(Modifier.fillMaxWidth()){Column(Modifier.padding(20.dp)){Text("Consistency",fontSize=20.sp);Text("${if(total==0)0 else completed*100/total}%",fontSize=40.sp,fontWeight=FontWeight.Bold);Text("Keep it up!",color=Muted)}}}}}
@Composable fun MetricGrid(total:Int,focused:Long,c:Int,st:Int,sk:Int,avg:Long){Column(verticalArrangement=Arrangement.spacedBy(10.dp)){Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){Metric("Sessions",total.toString());Metric("Focused",formatDuration(focused))};Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){Metric("Completion","${if(total==0)0 else c*100/total}%");Metric("Average",formatDuration(avg))};Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){Metric("Stopped","${if(total==0)0 else st*100/total}%");Metric("Skipped","${if(total==0)0 else sk*100/total}%")}}}
@Composable fun RowScope.Metric(t:String,v:String){GlassCard(Modifier.weight(1f).height(100.dp)){Column(Modifier.padding(16.dp)){Text(t,color=Muted,fontSize=12.sp);Text(v,fontSize=24.sp,fontWeight=FontWeight.SemiBold)}}}
@Composable fun BarChart(s:List<Session>){Canvas(Modifier.fillMaxSize()){if(s.isEmpty())return@Canvas;val bw=size.width/(s.size*1.5f);val max= max(1f,s.maxOf{it.elapsedSeconds}.toFloat());s.forEachIndexed{i,x->val h=(x.elapsedSeconds/max)*size.height*.72f;drawRoundRect(Color.White.copy(.65f),Offset(i*bw*1.5f,size.height-h),Size(bw,h),cornerRadius=CornerRadius(10f));}}}

@Composable fun Settings(vm:TimerVM){Column(Modifier.fillMaxSize()){Header("Settings",{vm.screen=Screen.HOME});Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)){GlassCard(Modifier.fillMaxWidth()){Column(Modifier.padding(20.dp)){Text("Profile",fontSize=18.sp,fontWeight=FontWeight.SemiBold);Text(vm.profile.name,color=Muted);Text(vm.profile.workspace,color=Muted);Spacer(Modifier.height(16.dp));SettingToggle("Sound",vm.sound){vm.setSetting("sound",it)};SettingToggle("Haptics",vm.haptics){vm.setSetting("haptics",it)};SettingToggle("High quality 3D",vm.quality){vm.setSetting("highQuality",it)};SettingToggle("Reduced motion",vm.reducedMotion){vm.setSetting("reducedMotion",it)}}};Spacer(Modifier.height(14.dp));GlassCard(Modifier.fillMaxWidth()){Column(Modifier.padding(20.dp)){Text("Timer defaults",fontSize=18.sp,fontWeight=FontWeight.SemiBold);Text("${vm.selectedHours}h ${vm.selectedMinutes}m",color=Muted);Spacer(Modifier.height(16.dp));Text("Notifications are local and generated when a background timer finishes.",color=Muted,fontSize=13.sp)}};Spacer(Modifier.height(14.dp));GlassCard(Modifier.fillMaxWidth()){Column(Modifier.padding(20.dp)){Text("About",fontSize=18.sp,fontWeight=FontWeight.SemiBold);Text("Premium 3D Timer · v1.0",color=Muted)}}}}}
@Composable fun SettingToggle(title:String,value:Boolean,on:(Boolean)->Unit){Row(Modifier.fillMaxWidth().padding(vertical=5.dp),verticalAlignment=Alignment.CenterVertically){Text(title,Modifier.weight(1f));Switch(value,on)}}

fun formatDuration(sec:Long):String{val h=sec/3600;val m=(sec%3600)/60;val s=sec%60;return "%02d:%02d:%02d".format(h,m,s)}
